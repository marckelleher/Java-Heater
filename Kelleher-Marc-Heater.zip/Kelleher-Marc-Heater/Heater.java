
/**
 * Heater project
 * Simulate the behavior of a heater (thermostat)
 * You can set the temperature and increase and decrease the temperature
 * @author Marc Kelleher 
 * @version 7/20/2015
 * MODIFICATIONS:
 * @author Marc Kelleher 
 * Added the methods warmer and cooler that increase and decrease the temperature
 * Added the method setDefaults to reset the variable fields
 */
public class Heater
{
    // instance variables
    private int temperature;
    private int minimum;
    private int maximum;
    private int increment;


    /**
     * Description: A constructor for objects of class Heater
     */
    public Heater()
    {
        //initialize instance variables
        minimum = 0;
        maximum = 100;
        increment = 1;
        temperature = 50;
    }
    
    /**
     * Description: A constructor for objects of class Heater that allows you to set the values
     * An error message will display and defaults values applied if values are not valid
     * @param temperature -- the temperature to initialize thermometer to
     * @param minimum -- the lowest that the temperature can be set to
     * @param maximum -- the highest that the temperature can be set to
     * @param increment -- the amount to increase or decrease the temperature
     */
    public Heater(int temperature, int minimum, int maximum, int increment)
    {
        if(minimum > maximum)
        {
            System.out.println("Minimum must be greater than maximum.");
            setDefaults();
        }
        else if(increment <= 0)
        {
            System.out.println("Increment must be greater than 0.");
            setDefaults();        
        }
        else if(temperature < minimum || temperature > maximum)
        {
            System.out.println("Temperature must not be less than minimum or greater than maximum.");
            setDefaults();        
        }
        else
        {
            this.temperature = temperature;
            this.minimum = minimum;
            this.maximum = maximum;
            this.increment = increment;
        }
    }

    /**
     * Name: getTemperature
     * Description: returns the value of temperature
     * @return the temperature
     */
    public int getTemperature()
    {
        return temperature;
    }
    
    /**
     * Name: getMinimum
     * Description: returns the value of minimum
     * @return the minimum
     */
    public int getMinimum()
    {
        return minimum;
    }
    
    /**
     * Name: getMaximum
     * Description: returns the value of maximum
     * @return the maximum
     */
    public int getMaximum()
    {
        return maximum;
    }
    
    /**
     * Name: getIncrement
     * Description: returns the value of increment
     * @return the increment
     */
    public int getIncrement()
    {
        return increment;
    }
    
    /**
     * Name: setTemperature
     * Description: sets the value of temperature
     * @param temperature - the temperature in fahrenheit
     */
    public void setTemperature(int temperature)
    {
        if(temperature < minimum || temperature > maximum)
        {
            System.out.println("Please enter a valid amount.");        
        }
        else 
        {
            this.temperature = temperature;
        }
    }
    
    /**
     * Name: setMinimum
     * Description: sets the value of minimum
     * @param minimum - the minimum temperature in fahrenheit
     */
    public void setMinimum(int minimum)
    {
        if(minimum > temperature || minimum > maximum)
        {
            System.out.println("Please enter a valid amount.");
        }
        else
        {
            this.minimum = minimum;
        }
    }
    
    /**
     * Name: setMaximum
     * Description: sets the value of maximum
     * @param maximum - the maximum temperature in fahrenheit
     */
    public void setMaximum(int maximum)
    {
        if(maximum < temperature || maximum < minimum)
        {
            System.out.println("Please enter a valid amount.");
        }
       else
        {
            this.maximum = maximum;
        }
    }
    
    /**
     * Name: setIncrement
     * Description: sets the value of increment
     * @param increment - the amount to change the temperature in fahrenheit
     */
    public void setIncrement(int increment)
    {
        if(increment > 0) 
        {
            this.increment = increment;
        }
        else
        {
            System.out.println("Please enter a positive integer value.");
        }
    }
    
    /**
     * Name: warmer
     * Description: increases the temperature by the value of increment
     * Displays an error if temperature is set above the maximum.
     */
    public void warmer()
    {
        if(temperature + increment <= maximum)
        {
            temperature = temperature + increment;
        }
        else
        {
            System.out.println("You cannot set the temperature above the maximum value of " + maximum + ".");
        }
    }
    
    /**
     * Name: cooler
     * Description: decreases the temperature by the value of increment.  
     * Displays an error if temperature is set below the minimum.
     */
    public void cooler()
    {
        if(temperature - increment >= minimum)
        {
            temperature = temperature - increment;
        }
        else
        {
            System.out.println("You cannot set the temperature below the minimum value of " + minimum + ".");
        }
    }
    
    /**
     * Name: setDefaults
     * Description: sets all values to default and displays a message.
     */
    public void setDefaults()
    {
        minimum = 0;
        maximum = 100;
        increment = 1;
        temperature = 50;
        System.out.println("All values have been set to default.");
    }
}
